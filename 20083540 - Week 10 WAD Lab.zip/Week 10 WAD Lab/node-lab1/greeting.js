const greeting = {
    en: "Hello World!",
    fr: "Bonjour!"
};

export default greeting;