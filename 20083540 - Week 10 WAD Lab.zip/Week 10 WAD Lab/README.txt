# Web App Dev 2: Web API Labs

Practical labs for the WAD2 module, BSc. Applied/Software Systems Dev/Forensics  
Student #20083540