import React from "react";

const favouriteMoviesPage = () => {
    return <h2>Favourite Movies</h2>
}

export default favouriteMoviesPage